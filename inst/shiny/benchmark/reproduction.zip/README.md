# Reproduce the current clean matched study

This download contains frozen sources and inputs for the 100-seed, four-condition
comparison. It contains no trained models. Extract it and set your working
directory to this folder. Install the recorded Python and R dependencies first;
see dev/research/keras-clean-reference/CONTRIBUTING_SEEDS.md and protocol.json.
Use CPU execution. Set PYTHON to your Python executable if needed, and set
DDESONN_REFERENCE_BLAS to a library exporting cblas_sgemm (original Linux path:
/usr/lib/x86_64-linux-gnu/libblas.so.3). Non-Linux execution is untested.

In R, source any of the four named launcher scripts. Each defaults to seeds
1-100, 360 epochs and the original settings; it prepares inputs, runs independent
numerical checks, then trains its condition. All four use the same study-results
folder and skip completed fit files. Run launchers sequentially. Keras fitting and
shared initialization require Python even when launched from R. For a shorter
range, source RUN_STUDY.R then run_study('keras','mean', first=1, last=10).

For seeds above 100 use the community extension workflow instead. Keep new results
separate from the frozen report. The original matched native runner is preserved
for provenance; launchers use the portable community native runner with identical
training and metric code. The unchanged historical compile.R contains original
workspace paths and is not the portable launcher.

The Shiny Show full R code button reproduces the displayed analysis of saved
results. These launchers rerun training, which can take hours. Neither is run
merely by viewing or downloading it. DDESONN here is the experimental native
float32 adapter; it is not the unchanged default trainer.
