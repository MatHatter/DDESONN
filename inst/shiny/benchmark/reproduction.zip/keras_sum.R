# Run from the extracted reproduction bundle root.
source("RUN_STUDY.R")
run_study("keras", "sum")
