# Run from the extracted bundle root; requires the recorded R/Python environment.
# See dev/research/keras-clean-reference/CONTRIBUTING_SEEDS.md.
run_study <- function(framework, reduction, output = "study-results", first = 1L,
                      last = 100L, python = Sys.getenv("PYTHON", "python")) {
  stopifnot(framework %in% c("keras", "ddesonn"), reduction %in% c("sum", "mean"),
            length(first)==1, length(last)==1, first %% 1==0, last %% 1==0,
            first >= 1, last >= first, last <= 100)
  scripts <- "dev/research/keras-clean-reference"
  execute <- function(command, args) {
    status <- system2(command, vapply(args, shQuote, character(1)))
    if (!identical(as.integer(status), 0L)) stop("Command failed; see output above")
  }
  execute(python, c("prepare_original.py", output))
  output <- normalizePath(output)
  # Portable independent numerical checks before training.
  execute(python, c(file.path(scripts,"community/check_tensorflow.py"), output))
  rscript <- file.path(R.home("bin"), "Rscript")
  execute(rscript, c(file.path(scripts,"community/check_native.R"), output))
  if (framework == "keras") {
    execute(python, c(file.path(scripts,"run_keras.py"), output, reduction, first, last))
  } else {
    execute(rscript, c(file.path(scripts,"community/run_native.R"), output,
                        if (reduction == "mean") "TRUE" else "FALSE", first, last))
  }
}
