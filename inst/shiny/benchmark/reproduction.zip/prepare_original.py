from pathlib import Path
import shutil, sys, json
root = Path(sys.argv[1]).resolve()
study = Path(__file__).resolve().parent / 'dev/research/keras-clean-reference'
sys.path.insert(0, str(study))
from community.extension import canonical
protocol = canonical()  # fail if any frozen training source differs
import importlib.metadata, os
for package, version in protocol['software']['python'].items():
    assert importlib.metadata.version(package.replace('_','-')) == version, package
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
from audit_split import audit
if root.exists():
    audit(root)
    assert all((root / f'initial-{s}.json').exists() for s in range(1, 101))
else:
    root.mkdir(parents=True)
    shutil.copyfile(study/'split-rows.csv', root/'split-rows.csv')
    from reference import prepare
    prepare(root)
    assert audit(root) == json.loads((study/'protocol.json').read_text())['audit']
print('Original seeds 1-100 prepared; no fitting in preparation.')
